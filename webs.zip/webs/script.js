function showip(){
   document.getElementById("ipaddr").innerHTML = ipval;
}